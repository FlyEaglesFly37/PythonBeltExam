from django.apps import AppConfig


class RetakeConfig(AppConfig):
    name = 'retake'
